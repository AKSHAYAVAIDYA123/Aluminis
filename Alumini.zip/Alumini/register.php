<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Socail Network | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body   background="dist\img\1.jpg" height="100">

  
     <?php include_once("header1.php"); ?>
 

 <div class="col-md-0">
 </div>
 <div class="col-md-5">
  
  <!-- /.login-logo -->
  <div class="form-box">
                            <div class="form-top">
                              <div class="form-top-left">
                                <h3>Sign up now</h3>
                                  <p>Fill in the form below to get instant access:</p>
                              </div>
                              <div class="form-top-right">
                                <i class="fa fa-pencil"></i>
                              </div>
                              </div>
                              <div class="form-bottom">
    <form id="registerForm" action="index.html" method="post">
      <div class="form-group has-feedback">
        <input type="text" id="name" name="name" class="form-control" placeholder="Full name" required>
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
        <span id="nameError" class="color-red hide-me">Name Error</span>
      </div>
      <div class="form-group has-feedback">
        <input type="email" id="email" name="email" class="form-control" placeholder="Email" required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <span id="emailError" class="color-red hide-me">Email Error</span>
        <span id="emailExistsError" class="color-red hide-me">Email Error</span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <span id="passwordError" class="color-red hide-me">Password Error</span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" id="cpassword" name="cpassword" class="form-control" placeholder="Retype password" required>
        <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
        <span id="cpasswordError" class="color-red hide-me">Confirm Password Error</span>
      </div>
       <div class="form-group has-feedback">
        <input type="text" id="passout" name="passout" class="form-control" placeholder="Year of Passout" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <span id="passout" class="color-red hide-me">Year of Passout</span>
      </div>
      <div class="form-group has-feedback">
     <!--   <input type="text" id="department" name="department" class="form-control" placeholder="Department" required>
        <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
        <span id="department" class="color-red hide-me">Department</span>-->
         <select name="department" class="form-control">
 <option value="MCA">MCA</option>
 <option value="MCOM">MCOM</option>
 
 </select>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox" required> I agree to the terms</a>
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button id="sbtBtn" type="submit" class="btn btn-primary btn-block btn-flat">Register</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <a href="login.php" class="text-center">I already have an account</a>
  </div>
  <!-- /.form-box -->
</div>
<!-- /.register-box -->
</div>
<div class="col-md-7"> 
  <div id="slider"   >
<figure>
<img src="images/p5.jpg" height="610" width="100">
<img src="images/p6.jpg" title="wewaeff" height="610" width="100%">
<img src="images/p2.jpg" height="610" width="100%" width="100%">
<img src="images/p3.jpg" height="610" width="100%">
<img src="images/p4.jpg" height="610" width="100%">
</figure> 

</div>  
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
<script>
  $('#registerForm').on("submit", function(e) {
    e.preventDefault();

    var errors = false;

    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

    //Minimum 8 Characters with at least 1 letter and 1 number
    var passwordReg = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;

    if($("#name").val().length < 5) {
      $("#nameError").text("Name Should Be Of Atleast 5 Chars");
      $("#nameError").show();
      errors = true;
    } else {
      $("#nameError").hide();
    }
 

    if(passwordReg.test($("#password").val())) {
      $("#passwordError").hide();
    } else {
        $("#passwordError").text("Password must be of 8 characters with at least 1 letter and 1 number");
        $("#passwordError").show();
        errors = true;
    }

    if($("#cpassword").val() === $("#password").val()) {
      $("#cpasswordError").hide();
    } else {
        $("#cpasswordError").text("Password Mismatch");
        $("#cpasswordError").show();
        errors = true;
    }

    if(errors == false) {
      if(emailReg.test($("#email").val())) {
        $("#emailError").hide();
        $.post("checkemail.php", { email: $("#email").val()}).done(function(data) {
          var result = $.trim(data);
          if(result == "Error") {
            $("#emailExistsError").text("This email is already registered with us. Choose Different Email.");
            $("#emailExistsError").show();
          } else {
            $("#emailExistsError").hide();
            adduser();
          } 
        });
      } else {
          $("#emailError").text("Email should be of format example@example.com");
          $("#emailError").show();
      }
    }
    



  });
</script>
<script>
  function adduser() {
     $.post("adduser.php", $("#registerForm").serialize() ).done(function(data) {
        var result = $.trim(data);
        if(result == "ok") {
          window.location.href = "login.php";
        }
      });
  }
</script>

</body>
</html>
