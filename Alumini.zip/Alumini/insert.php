 <html>
   
   <head>
      <title>Update a Record in MySQL Database</title>
       <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
   </head>
   
   <body>
      <?php
         if(isset($_POST['update'])) {
        $mysqli = new mysqli('localhost','root','','socialnetwork');

//Output any connection error
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
            
           
            $sub = $_POST['sub'];
             $msg = $_POST['msg'];
   //MySqli Update Query
$results = $mysqli->query("UPDATE users SET name1='$sub',msg='$msg' WHERE  type ='user'");

//MySqli Delete Query
//$results = $mysqli->query("DELETE FROM products WHERE ID=24");

if($results){
  
echo "<script>
alert('Message was successfully Added to the database');
window.location.href='bulk.php';
</script>";


}else{
    print 'Error : ('. $mysqli->errno .') '. $mysqli->error;
}         
   




         }else {
            ?>
            <div class="form-group">
               <form method = "post" action = "<?php $_PHP_SELF ?>">
                <br>
                <br>
                <br>
                <center><table width = "400" border =" 0" cellspacing = "1" 
                     cellpadding = "2">
                  
                 <caption><center><b>MESSAGE UPLOADED TO THE DATABASE</b></center></caption> 

                        <td width = "100"><b>SUBJECT</b></td>
                        <td><input name = "sub" type = "text" size="175" class="form-control hidden-print"
                           id = "sub"></td>

                     </tr>
                  <br>
                     <tr> 
                       <td width = "100"><b>MESSAGE</b></td>
                        <td>

                      <textarea rows="4" cols="50" name="msg" placeholder="Enter text here...">
</textarea>

   <br />
                       <!--   <input name = "msg" type = "text" size="175"
                           id = "msg"></td>-->
 
                     </tr>
                  
                     <tr>
                        <td width = "100"> </td>
                        <td>
                          <br>
                         <center>  <input name = "update" type = "submit" class="btn btn-success" 
                              id = "update" value = "ADD">
                        </td>
                     </tr>
                  
                  </table>
               </form>
             </div>
            <?php
         }
      ?>
      
   </body>
</html>
