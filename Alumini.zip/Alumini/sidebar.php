 <?php


 ?>
<aside class="main-sidebar" style="background-color:maroon;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" >
      <!-- Sidebar user panel--> <img src="images/logo2.jpg" align="left" height="130px" width="230px">
      <div class="user-panel">
        <div class="pull-left image">
          <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['profileimage'] != '') {
                    echo '<img src="uploads/profile/'.$row['profileimage'].'" class="img-circle" alt="User Image">';
                  } else {
                    echo '<img src="dist/img/avatar5.png" class="img-circle" alt="User Image">';
                  }
                  $username = $row['name'];
                  $type  = $row['type'];
                }
                ?>
        </div>

        <div class="pull-left info">
          <p><?php echo $username; ?></p>
            <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['online'] == '1') {
                    ?>
                        <a href="index.php?did=<?php echo $_SESSION['id_user']; ?>" ><i class="fa fa-circle text-success"></i> Online</a>
                                       <?php
                      if(isset($_GET['did']))
                      {
                            $sql2 = "UPDATE users SET online='0' WHERE id_user='$_GET[did]'";
                            if($conn->query($sql2) === TRUE) {
                          }
                     }


     

                   

                     } else {
                    ?>
                        <a href="index.php?did=<?php echo $_SESSION['id_user']; ?>" ><i class="fa fa-circle text-danger"></i> Offline</a>
                     
                    <?php
                     if(isset($_GET['did']))
                      {
                            $sql2 = "UPDATE users SET online='1' WHERE id_user='$_GET[did]'";
                            if($conn->query($sql2) === TRUE) {
                          }
                     }
                  }
                 
                }
                ?>
                    

                    
                    
       
        </div>
      </div>
      <!-- sidebar menu  -->
  
      <ul class="sidebar-menu" data-widget="tree">
  
  <?php
     if( $_SESSION['name']=='admin')
    { 
    ?>
       <li class="active treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu">
      
              <li <?php if($_SESSION['callFrom'] == "user-profile.php") { echo 'class="active"'; } ?>>
          <a href="user-profile.php">
            <i class="fa fa-circle-o"></i> <span>Profile</span>
          </a>
        </li>
 <li <?php if($_SESSION['callFrom'] == "user-work.php") { echo 'class="active"'; } ?>>
          <a href="user-work.php">
           <i class="fa fa-tasks" aria-hidden="true"></i><span>work</span>
          </a>
        </li>
<li <?php if($_SESSION['callFrom'] == "user-events.php") { echo 'class="active"'; } ?>>
          <a href="user-events.php">
            <i class="fa fa-calendar"></i> <span>events</span>
          </a>
        </li>


    </ul>
  </li>

           <li <?php if($_SESSION['callFrom'] == "user-index.php") { echo 'class="active"'; } ?>>
          <a href="user-index.php">
            <i class="fa fa-user-o"></i> <span>POST AS SUPER ADMIN</span>
          </a>
        </li>

<li class="  treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Normal User</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu">
       <li <?php if($_SESSION['callFrom'] == "profile.php") { echo 'class="active"'; } ?>>
          <a href="profile.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Profile</span>
          </a>
        </li>  
        <li <?php if($_SESSION['callFrom'] == "batch.php") { echo 'class="active"'; } ?>>
          <a href="batch.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Batch</span>
          </a>
        </li>   
      <!--  <li <?php if($_SESSION['callFrom'] == "index.php") { echo 'class="active"'; } ?>>
          <a href="index.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>ADMIN POST</span>
          </a>
        </li>-->
        <li <?php if($_SESSION['callFrom'] == "messages.php") { echo 'class="active"'; } ?>>
          <a href="messages.php">
            <i class="fa fa-wechat"></i> <span>Messages</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "friends.php") { echo 'class="active"'; } ?>>
          <a href="friends.php">
            <i class="fa fa-users"></i> <span>Friends</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "users.php") { echo 'class="active"'; } ?>>
          <a href="users.php">
            <i class="fa fa-users"></i> <span>Registered Aluminies</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "friend-request.php") { echo 'class="active"'; } ?>>
          <a href="friend-request.php">
            <i class="fa fa-users"></i> <span>Friend Requests</span>
          </a>
        </li>

      
    <!--    <li <?php if($_SESSION['callFrom'] == "pages.php") { echo 'class="active"'; } ?>>
          <a href="pages.php">
            <i class="fa fa-file-o"></i> <span>Pages</span>
          </a>
        </li>-->
        <li <?php if($_SESSION['callFrom'] == "events.php") { echo 'class="active"'; } ?>>
          <a href="events.php">
            <i class="fa fa-calendar"></i> <span>Events</span>
          </a>
        </li>
        <li>
          <a href="photos.php">
            <i class="fa  fa-file-photo-o"></i> <span>Photos</span>
          </a>
        </li>


    </ul>
  </li>

   <!--    
         <li <?php if($_SESSION['callFrom'] == "../Profile.php") { echo 'class="active"'; } ?>>
          <a href="../Profile.php">
           
<i class="fa fa-sign-in" style="font-size:20px"></i> <span>Visited as User</span>
          </a>
        </li>-->

         

          <li <?php if($_SESSION['callFrom'] == "user-search.php") { echo 'class="active"'; } ?>>
          <a href="user-search.php">
            <i class="fa fa-search"></i> <span>search</span>
          </a>
        </li>

          <li <?php if($_SESSION['callFrom'] == "eventadd.php") { echo 'class="active"'; } ?>>
          <a href="eventadd.php">
            <i class="fa fa-search"></i> <span>Event ADD</span>
          </a>
        </li>

        
            <li class="treeview" >
      <a href="#">
       <i class="fa fa-envelope-o"></i>
        <span>Mail</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
           <li <?php if($_SESSION['callFrom'] == "email.php") { echo 'class="active"'; } ?>>
          <a href="email.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>email</span>
          </a>
        </li> 

         <li <?php if($_SESSION['callFrom'] == "csv.php") { echo 'class="active"'; } ?>>
          <a href="csv.php">
            <i class="fa fa-circle-o text-red"></i> <span>Unregister contact</span>
          </a>
        </li> 
     
     </ul>
    <li class="treeview" >
      <a href="#">
       <i class="fa fa-edit"></i>
        <span>Analysis</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
            <li <?php if($_SESSION['callFrom'] == "deptstat.php") { echo 'class="active"'; } ?>>
          <a href="deptstat.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>based on department</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "passout.php") { echo 'class="active"'; } ?>>
          <a href="passout.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>passout</span>
          </a>
        </li>
    </li>  
  </ul>
    
  
  
  <?php }?>
    <?php
      
    if( $_SESSION['name']!='admin')
      {
      ?>
          <li <?php if($_SESSION['callFrom'] == "profile.php") { echo 'class="active"'; } ?>>
          <a href="profile.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Profile</span>
          </a>
        </li> 


         


        <li <?php if($_SESSION['callFrom'] == "batch.php") { echo 'class="active"'; } ?>>
          <a href="batch.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Batch</span>
          </a>
        </li>   
        <li <?php if($_SESSION['callFrom'] == "index.php") { echo 'class="active"'; } ?>>
          <a href="index.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>ADMIN POST</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "messages.php") { echo 'class="active"'; } ?>>
          <a href="messages.php">
            <i class="fa fa-wechat"></i> <span>Messages</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "friends.php") { echo 'class="active"'; } ?>>
          <a href="friends.php">
            <i class="fa fa-users"></i> <span>Friends</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "users.php") { echo 'class="active"'; } ?>>
          <a href="users.php">
            <i class="fa fa-users"></i> <span>Registered Aluminies</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "friend-request.php") { echo 'class="active"'; } ?>>
          <a href="friend-request.php">
            <i class="fa fa-users"></i> <span>Friend Requests</span>
          </a>
        </li>
  <li <?php if($_SESSION['callFrom'] == "eventadd.php") { echo 'class="active"'; } ?>>
          <a href="eventadd.php">
            <i class="fa fa-search"></i> <span>Event ADD</span>
          </a>
        </li>
      
    <!--    <li <?php if($_SESSION['callFrom'] == "pages.php") { echo 'class="active"'; } ?>>
          <a href="pages.php">
            <i class="fa fa-file-o"></i> <span>Pages</span>
          </a>
        </li>-->
        <li <?php if($_SESSION['callFrom'] == "events.php") { echo 'class="active"'; } ?>>
          <a href="events.php">
            <i class="fa fa-calendar"></i> <span>Events</span>
          </a>
        </li>
        <li>
          <a href="photos.php">
            <i class="fa  fa-file-photo-o"></i> <span>Photos</span>
          </a>
        </li>

       
        
    <?php
  }
    ?>
   

  
</ul>

    </section>
    <!-- /.sidebar -->
  </aside>