<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Socail Network | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body ></body>

 <!-- <a href="dist\img\1.jpg" ><body   background="dist\img\1.jpg" height="100">-->
     <?php include_once("header1.php"); ?>

 <div class="col-md-0" style="background-color:orange; color: white;">
 </div>
 <div class="col-md-5" style="background-color: black;  padding-left: 0; padding-right: 0;" >
    <img src="images/logo2.jpg" align="center" height=130px> 
  <h2 style=" color: gold; "><b>WENAMITTA </b></h2>
     <h4 style="color: white;"s><b>NMAMIT ALUMINI ASSOCIATION</b></h4>
  <!-- /.login-logo -->
  <div  >
                            <div class="form-top" style="background-color: maroon; padding: 0 25px 0px 25px; border-color: black;">
                              <div class="form-top-left">
                                <h3>Login to our site</h3>
                                  <p>Enter username and password to log on:</p>
                              </div>
                              <div class="form-top-right">
                                <i class="fa fa-lock"></i>
                              </div>
                              </div>
                              <div class="form-bottom" style="background-color: maroon; padding: 25px 25px 1px 25px;">
                     
                           
    <form id="loginForm" method="post">
      <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>          
        </div>
        <!-- /.col -->
      </div>
      <div class="row">
        <div class="col-xs-12">
            <span id="loginError" class="color-red hide-me">Invalid Email/Password!</span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form>
    <!-- /.social-auth-links -->

    <a href="#">I forgot my password</a><br>
    <a href="register.php" class="text-center">Create an account</a>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
</div>

<div class="col-md-7" style="padding-left: 0; padding-right: 0;"> 
  <div id="slider"   >
<figure>
<img src="images/p5.jpg" height="602" width="100">
<!--<img src="images/p6.jpg" title="wewaeff" height="700" width="100%">
<img src="images/p2.jpg" height="700" width="100%" width="100%">
<img src="images/p3.jpg" height="700" width="100%">
<img src="images/p4.jpg" height="700" width="100%">-->
<img src="images/p6.jpg" title="wewaeff" height="602" width="100%">
<img src="images/p2.jpg" height="602" width="100%" width="100%">
<img src="images/p3.jpg" height="602" width="100%">
<img src="images/p4.jpg" height="602" width="100%">-->
</figure> 

</div>  
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
<script>
  $(function() {
    $("#registeredSuccessfully:visible").fadeOut(8000);
  });
</script>
<script>
  $("#loginForm").on("submit", function(e) {
    e.preventDefault();
    $.post("checklogin.php", $(this).serialize() ).done(function(data) {
        var result = $.trim(data);
        if(result == "ok") {
          window.location.href = "index.php";
        }else if(result == "okay") {
          window.location.href = "user-profile.php";
        } else {
          $("#loginError").show();
        }
      });
  });
</script>
</body>
</html>
