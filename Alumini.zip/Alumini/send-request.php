

  <?php 


session_start();

require_once("db.php");

 $sql = "SELECT * FROM users WHERE id_user='$_GET[id]'";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $designation = $row['designation'];
    $email = $row['email'];
    $degree = $row['degree'];
    $university = $row['university'];
    $city = $row['city'];
    $country = $row['country'];
    $skills= $row['skills'];
    $aboutme = $row['aboutme'];
    $profileimage = $row['profileimage'];
  }
}
  
 


if(isset($_POST['send'])) {
	
	$uid=$_POST['uid'];
	$purpose=$_POST['purpose'];
	$sql = "SELECT * FROM friendrequest WHERE id_user='$uid' AND id_friend='$_SESSION[id_user]'";
	
	$result = $conn->query($sql);
	if($result->num_rows == 0) {
		$sql1 = "INSERT INTO `friendrequest`( `id_user`, `id_friend`, `purpose`) VALUES('$uid', '$_SESSION[id_user]','$purpose')";
		
		if($conn->query($sql1) === TRUE) {
      echo $name;
echo $email;
$name1=$name;
require 'class/class.phpmailer.php';
  $output = '';
  

    $txt=$name;
    $txt2="You have one friendrequest from  '$name' to view more visited site";
    $mail = new PHPMailer;
    $mail->IsSMTP();                //Sets Mailer to send message using SMTP
    $mail ->Host = "smtp.gmail.com";
      $mail ->Port = 465; // or 587
      $mail->SMTPAuth = true;             //Sets SMTP authentication. Utilizes the Username and Password variables
     $mail ->Username = "akshayakvaidya@gmail.com";
   $mail ->Password = "9740769579";
     $mail->SMTPSecure = 'ssl';             //Sets connection prefix. Options are "", "ssl" or "tls"
    //$mail->From = 'info@webslesson.com';      //Sets the From email address for the message
    //$mail->FromName = 'Webslesson';         //Sets the From name of the message
     $mail ->SetFrom("akshayakvaidya@gmail.com","ABV");
    $mail->AddAddress($email, $row["name"]); //Adds a "To" address
    $mail->WordWrap = 50;             //Sets word wrapping on the body of the message to a given number of characters
    $mail->IsHTML(true);              //Sets message type to HTML
    //$mail->Subject = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'; //Sets the Subject of the message
    //An HTML or plain text message body
    $mail->Subject = $txt;
    $mail->Body = $txt2;
    
    $mail->AltBody = '';

    $result = $mail->Send();            //Send an Email. Return true on success or false on error

    if($result["code"] == '400')
    {
      $output .= html_entity_decode($result['full_error']);
    }
			header("Location: users.php");
			exit();
		} else {
			echo $conn->error;
		}
	}
 
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Social Network</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

  <section class="content-header">
      <h1>
        Friends
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-12">

        <?php

        if(isset($_GET['id']))
        {

        ?>

        	<div class="panel panel-info">
          <div class="panel-heading">
            <h1>Create Page</h1>
          </div>
          <div class="panel-body">
            <form action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label>Purpose</label>
                <input type="text" name="uid" value="<?php echo $_GET['id']; ?>" hidden>
                <textarea name="purpose" class="form-control" required></textarea>
              </div>             
             
              <input type="submit" class="btn btn-success" name="send" value="Send">
            </form>
            
          </div>
        </div>

         <?php
     }
        ?>
          
        </div>

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2016-2017 <a href="#">Social Network</a>.</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
