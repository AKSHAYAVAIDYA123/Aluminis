
<?php
session_start();

$link = mysqli_connect("localhost", "root", "", "socialnetwork");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
if (isset($_POST['name'])) {
	$name = strip_tags($_POST['name']);
	$email = strip_tags($_POST['email']);
	$message = strip_tags($_POST['message']);
//	echo "<strong>Name</strong>: ".$name."</br>"; 
//	echo "<strong>Email</strong>: ".$email."</br>"; 
//	echo "<strong>Message</strong>: ".$message."</br>"; 
//	echo "<span class='label label-info'>Your feedback has been submitted with above details!</span>";
//$url = "https://www.youtube.com/watch?v=WpI3liNZ4a0";
preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $name, $match);
$youtube_id = $match[1];
echo $youtube_id;


	$sql = "INSERT INTO post (type,id_user,description, youtube) VALUES ('admin','$_SESSION[id_user]','$name', '$youtube_id')";
if(mysqli_query($link, $sql)){
   // header('location:indexddd.php');
    ?>
<a href="user-index.php">
    <?php 
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
 <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<link rel="stylesheet" type="text/css" href="dist\css\sweet alert.css'">
<script type="text/javascript" src="dist\js\sweetalert.js'"></script>
 


 
 
</head>
<body>
