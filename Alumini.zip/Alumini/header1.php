  <header id="header" class="main-header" style="background-color:orange;">

    <!-- Logo -->
    
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color:orange;">
      <!-- Sidebar toggle button-->
    <img src="images/logo.png"   height="60px" >
      <!-- Navbar Right Menu -->
     
                   <!-- Notifications: style can be found in dropdown.less -->

         </ul>
       </div>
          
      </div>

    </nav>
  </header>