<?php

session_start();

require_once("db.php");

if(isset($_POST)) {

	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);

	$password = base64_encode(strrev(md5($password)));
	$department = mysqli_real_escape_string($conn, $_POST['department']);
	$passout = mysqli_real_escape_string($conn, $_POST['passout']);

	$sql = "INSERT INTO users(name, email, password,name1,degree,designation) VALUES ('$name', '$email', '$password','$name','$passout','$department')";
	//$sql2 = "INSERT INTO search(name, email, degree,designation) VALUES ('$name', '$email','$passout','$department')";
	
	if($conn->query($sql)===TRUE) {
		$_SESSION['registeredSuccessfully'] = true;
		echo "ok";
	} else {
		echo "error";
	}
}