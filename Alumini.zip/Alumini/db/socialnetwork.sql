-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2018 at 06:58 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id_comment`, `id_user`, `id_friend`, `id_post`, `comment`, `createdAt`) VALUES
(1, 13, 13, 8, 'k', '2018-07-16 09:10:49');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Id` int(11) NOT NULL,
  `id_user` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `start` varchar(255) NOT NULL,
  `till` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `passout` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Id`, `id_user`, `name`, `company`, `position`, `place`, `start`, `till`, `email`, `department`, `passout`) VALUES
(1, '31', 'goutu', 'Robosoft', 'i', 'iuhiu', '9', '9', '', 'MCA', ''),
(2, '31', 'goutu', 'huh', 'uhuh', 'jh ', '8', '8', 'g1@gmail.com', 'MCA', ''),
(3, '31', 'goutu', 'hbu', 'uyh', 'u', '8', '8', 'g1@gmail.com', 'MCA', '2010'),
(4, '13', 'John Smith', 'Robosoft', 'Manager', 'udupi', '2010', '2012', 'savithavaidya7252@gmail.com', 'MCA', '2011'),
(5, '13', 'John Smith', 'Info', 'Kundapur', 'Udupi', '8', '8', 'savithavaidya7252@gmail.com', 'MCA', '2011'),
(6, '14', 'Username 1', 'Robosoft', 'kjbij', 'bjbjb', '88', '34', 'akshayakvaidya@gmail.com', 'MCA', '2010');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id_event` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id_event`, `id_user`, `name`, `color`) VALUES
(11, 13, 'New', 'text-yellow'),
(12, 17, 'ssdsds', 'text-blue');

-- --------------------------------------------------------

--
-- Table structure for table `event_calendar`
--

CREATE TABLE `event_calendar` (
  `id_calendar` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `bgColor` varchar(255) NOT NULL,
  `borderColor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_calendar`
--

INSERT INTO `event_calendar` (`id_calendar`, `id_user`, `title`, `day`, `month`, `year`, `bgColor`, `borderColor`) VALUES
(4, 17, 'ssdsds', 16, 6, 2018, 'rgb(60, 141, 188)', 'rgb(60, 141, 188)'),
(5, 17, 'ssdsds', 10, 6, 2018, 'rgb(0, 115, 183)', 'rgb(255, 255, 255)');

-- --------------------------------------------------------

--
-- Table structure for table `friendrequest`
--

CREATE TABLE `friendrequest` (
  `id_friendrequest` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `viewed` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendrequest`
--

INSERT INTO `friendrequest` (`id_friendrequest`, `id_user`, `id_friend`, `purpose`, `viewed`) VALUES
(2, 15, 18, 'dfg', 0),
(8, 15, 13, 'AMsdwdw', 0),
(16, 14, 17, 'kjnbhbj', 0),
(24, 14, 13, 'jj', 0),
(26, 16, 17, 'df', 0);

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id_friend` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_frienduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id_friend`, `id_user`, `id_frienduser`) VALUES
(15, 14, 16),
(16, 16, 14),
(17, 15, 16),
(18, 16, 15),
(21, 14, 15),
(22, 15, 14),
(41, 18, 13),
(42, 13, 18),
(43, 17, 13),
(44, 13, 17);

-- --------------------------------------------------------

--
-- Table structure for table `friends_comments`
--

CREATE TABLE `friends_comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `friend_posts`
--

CREATE TABLE `friend_posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friend_posts`
--

INSERT INTO `friend_posts` (`id_post`, `id_user`, `id_friend`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
(1, 14, 13, 'knj', '', '', '', '2018-07-17 13:16:55'),
(2, 13, 18, 'sd', '', '', '', '2018-07-17 18:40:24'),
(3, 13, 14, 'n j', '', '', '', '2018-07-17 18:41:14'),
(4, 13, 14, 'n', '', '', '', '2018-07-17 18:42:35'),
(5, 13, 14, 'ds', '', '', '', '2018-07-17 18:56:35'),
(6, 14, 13, 'dsf', '', '', '', '2018-07-18 04:51:41'),
(7, 14, 13, 'l,l', '', '', '', '2018-07-18 04:53:52'),
(9, 13, 14, 'dfwfd', '', '', '', '2018-07-18 07:05:22'),
(10, 13, 14, 'kjnkjk', '', '', '', '2018-07-18 07:06:15'),
(11, 13, 14, 'HI', '', '', '', '2018-07-18 07:07:39'),
(12, 13, 14, 'test', '', '', '', '2018-07-18 07:08:23'),
(13, 13, 14, 'uyg', '', '', '', '2018-07-18 07:09:39'),
(19, 13, 18, 'xdf', '', '', '', '2018-07-18 16:31:33'),
(20, 13, 18, 'HI', '', '', '', '2018-07-19 14:17:37'),
(21, 17, 13, 'Hi', '', '', '', '2018-07-20 07:46:50');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id_likes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `s` varchar(255) NOT NULL,
  `id_message` int(11) NOT NULL,
  `id_from` int(11) NOT NULL,
  `id_to` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `viewed` int(11) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Rohan` int(11) NOT NULL DEFAULT '1',
  `Se` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`s`, `id_message`, `id_from`, `id_to`, `message`, `viewed`, `createdAt`, `Rohan`, `Se`) VALUES
('', 30, 13, 14, 'q', 1, '2018-07-10 02:16:40', 0, 1),
('', 31, 13, 14, '1', 1, '2018-07-10 02:16:42', 0, 1),
('', 32, 13, 15, '1212', 1, '2018-07-10 02:16:49', 0, 1),
('', 33, 13, 15, 'ere', 1, '2018-07-10 02:16:56', 0, 1),
('', 34, 13, 16, 'dfsfs', 1, '2018-07-10 02:17:02', 0, 1),
('', 35, 14, 13, 'dfdf', 1, '2018-07-10 02:17:22', 0, 0),
('', 36, 14, 13, 'dfdf', 1, '2018-07-10 02:17:24', 1, 0),
('', 37, 14, 16, 'dfsfd', 1, '2018-07-10 02:17:40', 1, 1),
('', 38, 14, 15, '14', 1, '2018-07-10 02:17:24', 1, 1),
('', 39, 15, 16, '15-16', 1, '2018-07-10 02:17:40', 1, 1),
('', 40, 14, 13, 'dfi', 1, '2018-07-14 07:14:28', 1, 0),
('', 41, 14, 13, 'd', 1, '2018-07-14 07:45:45', 1, 0),
('', 42, 14, 13, 'd', 1, '2018-07-14 07:45:50', 1, 1),
('', 43, 14, 13, 'd', 1, '2018-07-14 07:45:50', 1, 1),
('', 44, 14, 13, 'd', 1, '2018-07-14 07:45:50', 1, 1),
('', 45, 14, 13, 'fgdg', 1, '2018-07-14 09:35:34', 1, 1),
('', 46, 16, 13, 'f', 1, '2018-07-14 12:25:27', 1, 1),
('', 47, 16, 13, 'd', 1, '2018-07-14 12:25:28', 1, 1),
('', 48, 16, 13, '', 1, '2018-07-14 12:25:28', 1, 1),
('', 49, 16, 13, '', 1, '2018-07-14 12:25:28', 1, 1),
('', 50, 16, 13, '', 1, '2018-07-14 12:25:28', 1, 1),
('', 51, 16, 13, 'd', 1, '2018-07-14 12:25:28', 1, 1),
('', 52, 16, 13, 'd', 1, '2018-07-14 12:25:29', 1, 1),
('', 53, 13, 16, 'j', 1, '2018-07-16 05:43:11', 1, 1),
('', 54, 13, 14, 'j', 1, '2018-07-16 09:13:54', 1, 1),
('', 55, 14, 15, 'username2', 1, '2018-07-16 15:51:15', 1, 1),
('', 56, 13, 14, 'dfd', 1, '2018-07-17 17:32:40', 1, 1),
('', 57, 13, 14, 'f', 1, '2018-07-17 17:34:40', 1, 1),
('', 58, 13, 14, ',', 1, '2018-07-17 17:36:55', 1, 1),
('', 59, 13, 14, 'l', 1, '2018-07-17 17:39:06', 1, 1),
('', 60, 13, 14, 'k', 1, '2018-07-17 17:40:00', 1, 1),
('', 61, 13, 14, 's', 1, '2018-07-17 17:41:10', 1, 1),
('', 62, 13, 14, 's', 1, '2018-07-17 17:44:58', 1, 1),
('', 63, 14, 13, 'd', 1, '2018-07-18 04:55:31', 1, 1),
('', 64, 14, 13, 'd', 1, '2018-07-18 04:55:32', 1, 1),
('', 65, 14, 13, 'd', 1, '2018-07-18 04:55:34', 1, 1),
('', 66, 14, 13, '', 1, '2018-07-18 04:55:44', 1, 1),
('', 67, 14, 13, 's', 1, '2018-07-18 04:55:45', 1, 1),
('', 68, 14, 13, 'f', 0, '2018-12-01 11:55:07', 1, 1),
('', 69, 14, 13, 'd', 0, '2018-12-01 11:55:09', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id_page` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id_page`, `id_user`, `name`, `description`, `logo`, `createdAt`) VALUES
(1, 17, 'kjhkn', 'kjkk', '5b498b5967341.png', '2018-07-14 05:34:17');

-- --------------------------------------------------------

--
-- Table structure for table `page_comments`
--

CREATE TABLE `page_comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_followers`
--

CREATE TABLE `page_followers` (
  `id_follower` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_likes`
--

CREATE TABLE `page_likes` (
  `id_likes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_posts`
--

CREATE TABLE `page_posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_posts`
--

INSERT INTO `page_posts` (`id_post`, `id_user`, `id_page`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
(1, 17, 1, 'DFSFS', '', '', '', '2018-07-14 05:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `type` varchar(255) NOT NULL,
  `id_post` int(11) NOT NULL,
  `id_user` varchar(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`type`, `id_post`, `id_user`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
('admin', 1, '17', 'Laeeq', NULL, '', '', '2018-07-20 04:28:16'),
('admin', 2, '17', 'Laeeq', NULL, '', '', '2018-07-20 04:28:36'),
('admin', 3, '17', 'Laeeq', NULL, '', '', '2018-07-20 04:28:47'),
('admin', 4, '17', 'Laeeq', NULL, '', '', '2018-07-20 04:29:07'),
('admin', 5, '17', 'Laeeq', NULL, '', '', '2018-07-20 04:29:46'),
('admin', 6, '17', 'Laeeq', NULL, '', '', '2018-07-20 04:30:56'),
('admin', 7, '17', 'sdadaLaeeq', NULL, '', '', '2018-07-20 04:32:24'),
('admin', 8, '17', 'https://www.youtube.com/watch?v=CQiulsfEjSA', NULL, '', 'CQiulsfEjSA', '2018-07-20 04:32:53'),
('admin', 9, '17', 'https://www.youtube.com/watch?v=sq3dUpIyXus', NULL, '', 'sq3dUpIyXus', '2018-07-20 04:35:33'),
('admin', 10, '17', 'https://www.youtube.com/watch?v=sq3dUpIyXus', NULL, '', 'sq3dUpIyXus', '2018-07-20 04:37:39'),
('admin', 11, '17', 'https://www.youtube.com/watch?v=wCsPAquMNVw', NULL, '', 'wCsPAquMNVw', '2018-07-20 07:13:49'),
('admin', 12, '17', 'https://www.youtube.com/watch?v=-MlkASchodc', NULL, '', '-MlkASchodc', '2018-07-20 07:15:34'),
('admin', 13, '17', 'h', '', '', '', '2018-07-20 07:23:13'),
('admin', 14, '17', 'https://www.youtube.com/watch?v=-MlkASchodc', NULL, '', '-MlkASchodc', '2018-07-20 07:31:11'),
('admin', 15, '17', 'https://www.youtube.com/watch?v=-MlkASchodc', NULL, '', '-MlkASchodc', '2018-07-20 07:34:30'),
('admin', 16, '17', 'https://www.youtube.com/watch?v=-MlkASchodc', NULL, '', '-MlkASchodc', '2018-07-20 07:37:29'),
('admin', 17, '17', 'https://www.youtube.com/watch?v=-MlkASchodc', NULL, '', '-MlkASchodc', '2018-07-20 07:38:47'),
('admin', 18, '17', 'https://www.youtube.com/watch?v=ir12Boxh__Q', NULL, '', 'ir12Boxh__Q', '2018-07-20 07:39:50'),
('admin', 19, '17', 'https://www.youtube.com/watch?v=-MlkASchodc', NULL, '', '-MlkASchodc', '2018-07-20 07:41:18'),
('frien', 20, '17', 'gi\r\n', '', '', '', '2018-07-20 07:43:44'),
('admin', 21, '17', 'hjashgdjgds', '', '', '', '2018-12-01 11:52:16'),
('admin', 22, '17', 's', '', '', '', '2018-12-01 11:54:15'),
('admin', 23, '17', 'Hi\r\n', '', '', '', '2018-12-02 10:47:00'),
('frien', 24, '14', 'e', '', '', '', '2018-12-02 10:50:15'),
('admin', 25, '17', 'd', '', '', '', '2018-12-02 11:16:00'),
('admin', 26, '17', 'sw', '', '', '', '2018-12-14 09:08:51'),
('frien', 27, '14', 'A', '', '', '', '2018-12-27 03:49:31'),
('frien', 28, '14', 'https://www.youtube.com/watch?v=IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', '', '', 'IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', '2018-12-27 04:10:10'),
('frien', 29, '14', '', '', '', '', '2018-12-27 04:11:14'),
('frien', 30, '14', '', '5c245177aea9d.png', '', '', '2018-12-27 04:13:43'),
('frien', 31, '14', '', '', '', '', '2018-12-27 04:14:31'),
('admin', 32, '17', 'https://www.youtube.com/watch?v=IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', NULL, '', 'IvmcGSDzZU8', '2018-12-27 04:15:36'),
('admin', 33, '17', 'https://www.youtube.com/watch?v=IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', NULL, '', 'IvmcGSDzZU8', '2018-12-27 04:15:39'),
('admin', 37, '17', 'https://www.youtube.com/watch?v=IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', NULL, '', 'IvmcGSDzZU8', '2018-12-27 05:10:34'),
('admin', 38, '17', 'https://www.youtube.com/watch?v=IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', NULL, '', 'IvmcGSDzZU8', '2018-12-27 05:12:03'),
('admin', 39, '17', 'https://www.youtube.com/watch?v=IvmcGSDzZU8&list=RDIvmcGSDzZU8&start_radio=1', NULL, '', 'IvmcGSDzZU8', '2018-12-27 05:12:37');

-- --------------------------------------------------------

--
-- Table structure for table `publicpost`
--

CREATE TABLE `publicpost` (
  `type` varchar(255) NOT NULL DEFAULT 'admin',
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publicpost`
--

INSERT INTO `publicpost` (`type`, `id_post`, `id_user`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
('admin', 1, 17, 'd', '', '', '', '2018-07-17 11:30:28'),
('admin', 2, 17, '', '5b4dd59bc3fef.jpg', '', '', '2018-07-17 11:40:11'),
('admin', 3, 17, '', '5b4dd5fa6d940.jpg', '', '', '2018-07-17 11:41:46'),
('admin', 4, 17, '', '5b4dd642641e3.png', '', '', '2018-07-17 11:42:58'),
('admin', 5, 17, '', '', '', '', '2018-07-17 11:43:01'),
('admin', 6, 17, '', '', '', '', '2018-07-17 11:43:02'),
('admin', 7, 17, '', '', '', '', '2018-07-17 11:43:02'),
('admin', 8, 17, '', '', '', '', '2018-07-17 11:43:03'),
('admin', 9, 17, 'w', '', '', '', '2018-07-17 11:43:05'),
('admin', 10, 17, 'kihihih', '', '', '', '2018-07-17 11:45:13'),
('admin', 11, 17, 'u', '', '', '', '2018-07-17 11:45:35'),
('admin', 12, 17, 'k', '', '', '', '2018-07-17 11:49:22'),
('admin', 13, 17, 'i', '', '', '', '2018-07-17 11:49:36'),
('admin', 14, 17, 'hj', '', '', '', '2018-07-17 11:53:32'),
('admin', 15, 17, '', '', '', '', '2018-07-17 11:53:35'),
('admin', 16, 17, '', '', '', '', '2018-07-17 11:53:36'),
('admin', 17, 17, '', '', '', '', '2018-07-17 11:53:36'),
('admin', 18, 17, '', '', '', '', '2018-07-17 11:53:36'),
('admin', 19, 17, '', '', '', '', '2018-07-17 11:53:37'),
('admin', 20, 17, 'p', '', '', '', '2018-07-17 11:54:58'),
('admin', 21, 17, 'sds', '', '', '', '2018-07-17 11:55:44'),
('admin', 22, 17, 's', '', '', '', '2018-07-17 12:04:24'),
('admin', 23, 17, 'd', '', '', '', '2018-07-17 12:07:24'),
('admin', 24, 17, 'v', '', '', '', '2018-07-17 12:07:27');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `gend` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`gend`) VALUES
('john@example.com'),
('john@example.com'),
('john@example.com'),
('john@example.com'),
('john@example.com'),
('john@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `unregister`
--

CREATE TABLE `unregister` (
  `type` varchar(255) NOT NULL DEFAULT 'user',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name1` text NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unregister`
--

INSERT INTO `unregister` (`type`, `name`, `email`, `name1`, `msg`) VALUES
('user', 'kevin_tom', 'kevin', 'ojoi', 'ojo'),
('user', 'vincy', 'vincy', 'ojoi', 'ojo'),
('user', 'tim_lee', 'tim', 'ojoi', 'ojo'),
('user', 'jane', 'jane', 'ojoi', 'ojo'),
('user', 'a', 'a', 'ojoi', 'ojo'),
('user', 'b', 'b', 'ojoi', 'ojo'),
('user', 'c', 'c', 'ojoi', 'ojo'),
('user', 'akshaya', 'akshayakvaidya@gmail.com', 'ojoi', 'ojo');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `type` varchar(10) NOT NULL DEFAULT 'user',
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `designation` varchar(255) NOT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `skills` text,
  `aboutme` text,
  `profileimage` varchar(255) DEFAULT NULL,
  `online` int(11) NOT NULL DEFAULT '0',
  `name1` varchar(255) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`type`, `id_user`, `name`, `email`, `password`, `createdAt`, `designation`, `degree`, `university`, `city`, `country`, `skills`, `aboutme`, `profileimage`, `online`, `name1`, `msg`) VALUES
('user', 13, 'John Smith', 'savithavaidya7252@gmail.com', 'MDA1YjgxZmQ5NjBmNjE1MDUyMzdkYmI3YTMyMDI5MTA=', '2017-09-04 14:45:47', 'MCA', '2011', 'Nitte', 'Manager', 'Australia', 'PHP HTML CSS', 'I like to code and teach. AND PLAY ', '5b46e8e5dd699.jpg', 0, 'message', 'frgdeg'),
('user', 14, 'Username 1', 'akshayakvaidya@gmail.com', 'MDA1YjgxZmQ5NjBmNjE1MDUyMzdkYmI3YTMyMDI5MTA=', '2017-09-04 14:45:47', 'MCA', '2010', 'ABCB', 'Sydney', 'Australia', 'PHP HTML CSS', 'I like to code and teach.', '59d7a48989ea1.png', 0, 'message', 'frgdeg'),
('user', 15, 'Username 2', 'savithavaidya7252@gmail.com', 'YjdlNDhmMTk4NjFhNDNjNGM2MDdhOGFlZTBiY2M3Mjg=', '2017-09-04 14:45:47', 'MCA', '2012', 'ABCB', 'Sydney', 'Australia', 'PHP HTML CSS', 'I like to code and teach.', '5b4dca45c2231.png', 0, 'message', 'frgdeg'),
('user', 16, 'Username 3', 'chitchat763@gmail.com', 'YjdlNDhmMTk4NjFhNDNjNGM2MDdhOGFlZTBiY2M3Mjg=', '2017-09-04 14:45:47', 'MBA', 'B.Tech', 'ABCB', 'Sydney', 'Australia', 'PHP HTML CSS', 'I like to code and teach.', '59d7a48989ea3.png', 0, 'message', 'frgdeg'),
('user', 17, 'admin', 'admin@gmail.com', 'MDA1YjgxZmQ5NjBmNjE1MDUyMzdkYmI3YTMyMDI5MTA=', '2018-07-12 09:55:08', '', '', '', '', '', '', 'Developer', NULL, 1, 'message', 'frgdeg'),
('user', 18, 'Ananth', 'akshayavaidya15@gmail.com', 'MDA1YjgxZmQ5NjBmNjE1MDUyMzdkYmI3YTMyMDI5MTA=', '2018-07-17 05:34:27', 'MBA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'message', 'frgdeg'),
('user', 25, 'ambika', 'ambika@gmail.com', 'MDA1YjgxZmQ5NjBmNjE1MDUyMzdkYmI3YTMyMDI5MTA=', '2018-07-18 10:20:06', 'MBA', '2010', NULL, NULL, NULL, NULL, NULL, NULL, 0, 'message', 'frgdeg');

-- --------------------------------------------------------

--
-- Table structure for table `user_followers`
--

CREATE TABLE `user_followers` (
  `id_follower` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_userfollower` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_followers`
--

INSERT INTO `user_followers` (`id_follower`, `id_user`, `id_userfollower`) VALUES
(1, 13, 18),
(2, 13, 18);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `event_calendar`
--
ALTER TABLE `event_calendar`
  ADD PRIMARY KEY (`id_calendar`);

--
-- Indexes for table `friendrequest`
--
ALTER TABLE `friendrequest`
  ADD PRIMARY KEY (`id_friendrequest`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id_friend`);

--
-- Indexes for table `friends_comments`
--
ALTER TABLE `friends_comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `friend_posts`
--
ALTER TABLE `friend_posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id_likes`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `page_comments`
--
ALTER TABLE `page_comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `page_followers`
--
ALTER TABLE `page_followers`
  ADD PRIMARY KEY (`id_follower`);

--
-- Indexes for table `page_likes`
--
ALTER TABLE `page_likes`
  ADD PRIMARY KEY (`id_likes`);

--
-- Indexes for table `page_posts`
--
ALTER TABLE `page_posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `publicpost`
--
ALTER TABLE `publicpost`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `user_followers`
--
ALTER TABLE `user_followers`
  ADD PRIMARY KEY (`id_follower`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `event_calendar`
--
ALTER TABLE `event_calendar`
  MODIFY `id_calendar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `friendrequest`
--
ALTER TABLE `friendrequest`
  MODIFY `id_friendrequest` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id_friend` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `friends_comments`
--
ALTER TABLE `friends_comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `friend_posts`
--
ALTER TABLE `friend_posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `page_comments`
--
ALTER TABLE `page_comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_followers`
--
ALTER TABLE `page_followers`
  MODIFY `id_follower` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_likes`
--
ALTER TABLE `page_likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_posts`
--
ALTER TABLE `page_posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `publicpost`
--
ALTER TABLE `publicpost`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_followers`
--
ALTER TABLE `user_followers`
  MODIFY `id_follower` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
