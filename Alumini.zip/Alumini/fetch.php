<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "socialnetwork");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM company 
  WHERE  name LIKE '%".$search."%' 
  OR  email LIKE '%".$search."%' 
  OR department LIKE '%".$search."%' 
  OR passout LIKE '%".$search."%'
  OR company LIKE '%".$search."%'
  OR position LIKE '%".$search."%'
  OR place LIKE '%".$search."%'
  OR start LIKE '%".$search."%'
  OR till LIKE '%".$search."%'
 ";
}
else
{
 $query = "
  SELECT * FROM company ORDER BY id_user
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     
     <th>Name</th>
     <th>Email</th>
     <th>Department</th>
     <th>Passout</th>
     <th>company</th>
     <th>Position</th>
     <th>place</th>
     <th>start</th>
     <th>till</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
      <td>'.$row["name"].'</td>
    <td>'.$row["email"].'</td>
    <td>'.$row["department"].'</td>
    <td>'.$row["passout"].'</td>
     <td>'.$row["company"].'</td>
     <td>'.$row["position"].'</td>
     <td>'.$row["place"].'</td>
     <td>'.$row["start"].'</td>
     <td>'.$row["till"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>